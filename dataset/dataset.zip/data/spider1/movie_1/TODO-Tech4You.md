Da fare Realmente
- Dockerizzazione BE
- Completare API FE-BE
- Creazione sistema per il report automatico in PDF human readable
- Root per Modelli locali e online
- Modello di esecuzione dei piani: task generato automaticamente, un sistema lo esegue e prende il feedback.

Da fare Teoricamente
- Completare l'API fra FE e BE
- Root per Modelli locali e online, in base ad un file di configurazione
- Modello di esecuzione dei piani: task generato automaticamente (già presente), un sistema lo esegue e prende il feedback, senza utilizzare il webdriver